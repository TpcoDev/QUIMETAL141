# -*- coding: utf-8 -*-
from odoo.tools.translate import _
from odoo import http
from odoo import http
from odoo.http import request
from tabulate import tabulate
from bs4 import BeautifulSoup
import jsonschema
from jsonschema import validate
import json
import sys
import uuid
import yaml
import logging
_logger = logging.getLogger(__name__)

esquema = {
            "$schema": "http://json-schema.org/draft-04/schema#",
            "type": "object",
            "properties": {
                "DocNum": {
                "type": "string"
                },
                "DocDate": {
                "type": "string"
                },
                "CardCode": {
                "type": "string"
                },
                "CardName": {
                "type": "string"
                },
                "WarehouseCode": {
                "type": "string"
                },
                "DatosProdOC": {
                "type": "array",
                "items": [
                    {
                    "type": "object",
                    "properties": {
                        "ItemCode": {
                        "type": "string"
                        },
                        "ItemDescription": {
                        "type": "string"
                        },
                        "Quantity": {
                        "type": "number"
                        },
                        "MeasureUnit": {
                        "type": "string"
                        }
                    },
                    "required": [
                        "ItemCode",
                        "ItemDescription",
                        "Quantity",
                        "MeasureUnit"
                    ]
                    },
                    {
                    "type": "object",
                    "properties": {
                        "ItemCode": {
                        "type": "string"
                        },
                        "ItemDescription": {
                        "type": "string"
                        },
                        "Quantity": {
                        "type": "number"
                        },
                        "MeasureUnit": {
                        "type": "string"
                        }
                    },
                    "required": [
                        "ItemCode",
                        "ItemDescription",
                        "Quantity",
                        "MeasureUnit"
                    ]
                    },
                    {
                    "type": "object",
                    "properties": {
                        "ItemCode": {
                        "type": "string"
                        },
                        "ItemDescription": {
                        "type": "string"
                        },
                        "Quantity": {
                        "type": "number"
                        },
                        "MeasureUnit": {
                        "type": "string"
                        }
                    },
                    "required": [
                        "ItemCode",
                        "ItemDescription",
                        "Quantity",
                        "MeasureUnit"
                    ]
                    }
                ]
                }
            },
            "required": [
                "DocNum",
                "DocDate",
                "CardCode",
                "CardName",
                "WarehouseCode",
                "DatosProdOC"
            ]
            }


class as_webservice(http.Controller):

    @http.route(['/api/ws001ok',], auth="public", type="json", method=['POST'], csrf=False)
    def request_WS001(self, **post):
        post = yaml.load(request.httprequest.data)
        res = {}
        token = uuid.uuid4().hex
        try:
            uid = request.session.authenticate(post['db'], post['login'], post['password'])
            if uid:
                res['token'] = token
                request.session.logout()

                es_valido = self.validar_json(post)
                if es_valido:
                    return {			
                        "Token": token,				
                        "RespCode":0,				
                        "RespMessage":"El JSON ha sido validado y es CORRECTO",
                        "json_recibido":post
                    }
                else:
                    return {			
                        "Token": token,				
                        "RespCode":0,				
                        "RespMessage":"El JSON ha sido validado y es INCORRECTO",
                        "json_recibido":post
                    }
            else:
                res['error'] = "Login o Password erroneo"
                res_json = json.dumps(res)

                return res_json
        except Exception as e:
            return {			
                    "Token": token,		
                    "RespCode":-1,		
                    "RespMessage":"Error de conexión",
                    "error": e.args
                }
    def validar_json(self,el_json):
        try:
            validate(instance=el_json, schema=esquema)
        except jsonschema.exceptions.ValidationError as err:
            return False
        return True
