# -*- coding: utf-8 -*-
{
    'name' : "Ahorasoft EQUIMETAL customizaciones",
    'version' : "1.0.0",
    'author'  : "Ahorasoft",
    'description': """
Webservice dummy equimetal
===========================

    """,
    'category' : "Sale",
    'depends' : ["base"],
    'website': 'http://www.ahorasoft.com',
    'data' : [

             ],
    'demo' : [],
    'installable': True,
    'auto_install': False
}
